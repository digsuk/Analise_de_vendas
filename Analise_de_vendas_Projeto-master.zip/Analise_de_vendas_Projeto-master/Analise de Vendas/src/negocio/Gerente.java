/*---------------------------------------------
 * Autor: Jonathan Moura
 * Data:29/04/2018
 *---------------------------------------------
 * Descri��o: Classe do gerente
 * 
 *---------------------------------------------
 * Hist�rico de modifica��o
 * Data    Autor    Descri��o
 *       |        |
 *-------------------------------------------*/
package negocio;

public class Gerente extends Funcionario{

	public Gerente(String nome, String cpf, String email, String senha, String funcao, String chave) {
		super(nome, cpf, email, senha, funcao, chave);
	}
	
}
