/*---------------------------------------------
 * Autor: Jonathan Moura
 * Data:29/04/2018
 *---------------------------------------------
 * Descri��o: Classe do vendedor
 * 
 *---------------------------------------------
 * Hist�rico de modifica��o
 * Data    Autor    Descri��o
 *       |        |
 *-------------------------------------------*/

package negocio;

public class Vendedor extends Funcionario{

	public Vendedor(String nome, String cpf, String email, String senha, String funcao, String chave) {
		super(nome, cpf, email, senha, funcao, chave);
		
	}

}